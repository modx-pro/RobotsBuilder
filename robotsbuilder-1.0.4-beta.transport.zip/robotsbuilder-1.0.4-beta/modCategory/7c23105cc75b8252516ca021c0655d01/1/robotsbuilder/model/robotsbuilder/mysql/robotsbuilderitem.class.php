<?php
require_once (dirname(__DIR__) . '/robotsbuilderitem.class.php');
class RobotsBuilderItem_mysql extends RobotsBuilderItem {}